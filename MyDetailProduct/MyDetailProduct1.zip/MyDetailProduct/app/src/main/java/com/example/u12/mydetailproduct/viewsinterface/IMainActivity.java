package com.example.u12.mydetailproduct.viewsinterface;

import com.example.u12.mydetailproduct.models.Product;

public interface IMainActivity {


    void intentToDetailActivity(Product product);
}
